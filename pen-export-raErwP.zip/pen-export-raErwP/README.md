# Minimalist calendar

A Pen created on CodePen.io. Original URL: [https://codepen.io/boudra/pen/raErwP](https://codepen.io/boudra/pen/raErwP).

